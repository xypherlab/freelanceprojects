import cv2
import time
while True:
	print cv2.__version__
	time.sleep(1)